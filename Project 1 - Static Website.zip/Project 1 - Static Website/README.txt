Project 1 - Deploy Static Website on AWS
Israel Andrade
israelcarneiro97@gmail.com


Cloudfront URL: 

d8rdoag06t2fg.cloudfront.net

------------------------------------

S3 Bucket Website Endpoint:

http://my-875171890960-bucket.s3-website-sa-east-1.amazonaws.com/